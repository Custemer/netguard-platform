require('dotenv').config();
const express = require('express');
const passport = require('passport');
const cors = require('cors');
const helmet = require('helmet');
const connectDB = require('./config/db');
const { createApiLimiter } = require('./lib/apiRateLimiter');
const { globalApiLimit } = require('./lib/rateLimitPolicy');
const { adminLoginIsConfigured } = require('./lib/adminIdentity');

const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const adminRoutes = require('./routes/admin');
const extensionRoutes = require('./routes/api');
const publicRoutes = require('./routes/public');
const assistantRoutes = require('./routes/assistant');
const siteProtectionRoutes = require('./routes/siteProtection');

const required = ['MONGODB_URI', 'JWT_SECRET'];
const missing = required.filter((name) => !process.env[name]);
if (missing.length) {
  throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
}

const app = express();
app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// The assistant accepts one transient base64 screenshot up to 4 MB. Protected-site
// telemetry is intentionally small and is validated again by its own router.
app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));

// Protected websites have their own origin validation and CORS response because
// their origins are registered dynamically in MongoDB.
app.use('/api/site', siteProtectionRoutes);

const configuredOrigins = (process.env.CORS_ORIGINS || process.env.FRONTEND_URL || '')
  .split(',')
  .map((value) => value.trim().replace(/\/$/, ''))
  .filter(Boolean);
const allowedOrigins = new Set([
  'http://localhost:5173',
  'http://localhost:3000',
  ...configuredOrigins,
]);

app.use(cors({
  origin(origin, callback) {
    const isChromeExtension = origin?.startsWith('chrome-extension://');
    if (!origin || allowedOrigins.has(origin) || isChromeExtension) return callback(null, true);
    return callback(new Error('Origin is not allowed by CORS'));
  },
  credentials: false,
}));

app.use(passport.initialize());
const googleOAuthEnabled = require('./config/passport')(passport);
app.locals.googleOAuthEnabled = googleOAuthEnabled;

const apiLimiter = createApiLimiter();
app.use('/api', apiLimiter);

app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/extension', extensionRoutes);
app.use('/api/public', publicRoutes);
app.use('/api/assistant', assistantRoutes);

app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    message: 'NetGuard API is running',
    version: '3.6.5',
    adminRecoveryConfigured: adminLoginIsConfigured(),
    apiRateLimitPerClient: globalApiLimit(),
    googleOAuth: googleOAuthEnabled,
    geminiAssistant: Boolean(process.env.GEMINI_API_KEY),
    websiteProtection: true,
    perSiteProtectionControls: true,
    automaticSitePostureScans: true,
    recaptchaProtection: Boolean(process.env.RECAPTCHA_SITE_KEY && process.env.RECAPTCHA_SECRET_KEY),
    timestamp: new Date().toISOString(),
  });
});

app.use((error, _req, res, _next) => {
  console.error('[server]', error.message);
  res.status(error.message.includes('CORS') ? 403 : 500).json({
    success: false,
    message: error.message.includes('CORS') ? 'Origin is not allowed' : 'Unexpected server error',
  });
});

const PORT = Number(process.env.PORT) || 5000;
connectDB()
  .then(() => app.listen(PORT, '0.0.0.0', () => {
    console.log(`[server] NetGuard API v3.6.5 listening on ${PORT}`);
  }))
  .catch((error) => {
    console.error('[server] Database connection failed:', error.message);
    process.exit(1);
  });

module.exports = app;
